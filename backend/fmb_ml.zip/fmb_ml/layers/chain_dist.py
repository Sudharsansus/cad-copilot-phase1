"""
layers/chain_dist.py — CHAIN LINE DISTANCE Layer
Draws distances along chain survey lines.

Verified from manual DXF:
  Layer name: CHAIN LINE DISTANCE
  Color:      251 (Light gray) — ByLayer
  Lineweight: 0
  Linetype:   1 (dashed)
  Height:     3.0m
  Count:      5 text entities in FMB 405

  Examples from manual:
    (70,8)   (134,0)   (182,2)   (43,8)   (74,6)

Note: These are in BRACKETS — (70,8) not 70,8
Note: Use COMMA format — (70,8) not (70.8)
"""

LAYER_NAME = "CHAIN LINE DISTANCE"
COLOR      = 256    # ByLayer (color 251 via layer)
LINEWEIGHT = 0
LINETYPE   = "1"    # Dashed — verified from manual
HEIGHT     = 3.0


def setup_layer(doc):
    """Register CHAIN LINE DISTANCE layer"""
    layer = doc.layers.add(LAYER_NAME)
    layer.dxf.color      = 251   # Light gray
    layer.dxf.lineweight = LINEWEIGHT
    layer.dxf.linetype   = LINETYPE


def draw(msp, texts: list, ph: float, pt_m: float):
    """
    Draw chain line distance labels.
    Always in bracket format: (70,8)  (134,0)
    
    Args:
        msp:   modelspace
        texts: OCR results filtered to type='chain_dist'
        ph:    page height for Y flip
        pt_m:  scale factor
    """
    count = 0
    seen  = set()

    for t in texts:
        if t.get("type") != "chain_dist":
            continue
        txt   = str(t.get("text", "")).strip()
        x     = float(t.get("x", 0)) * pt_m
        y     = (ph - float(t.get("y", 0))) * pt_m
        clean = txt.replace(".", ",")

        key = (clean, round(x, 0), round(y, 0))
        if key in seen or not txt:
            continue
        seen.add(key)

        msp.add_text(clean, dxfattribs={
            "insert":  (x, y),
            "height":  HEIGHT,
            "layer":   LAYER_NAME,
            "color":   COLOR,
        })
        count += 1

    print(f"   CHAIN LINE DISTANCE: {count} labels drawn")
