"""
layers/chain_line.py — WELL and BUILDING Layer
Draws the chain survey lines (blue diagonal measurement lines).

Verified from manual DXF:
  Layer name: WELL and BUILDING
  Color:      5 (Blue) — ByLayer
  Lineweight: 0
  Linetype:   Continuous
  Count:      1 entity with 18 points (zigzag pattern) in manual
              BUT PDF stores as 3 separate blue line segments

  In PDF: color = (0.0, 0.0, 1.0) — pure blue
  The zigzag pattern (W shape) = multiple connected segments

Purpose:
  Chain survey lines connect chain points (11,12,13,14,16,18)
  Used to measure distances across the parcel
  The W/zigzag symbol in middle = chain link marker
"""

LAYER_NAME = "WELL and BUILDING"
COLOR      = 256    # ByLayer (blue = 5 via layer)
LINEWEIGHT = 0
LINETYPE   = "Continuous"


def setup_layer(doc):
    """Register WELL and BUILDING layer"""
    layer = doc.layers.add(LAYER_NAME)
    layer.dxf.color      = 5    # Blue
    layer.dxf.lineweight = LINEWEIGHT
    layer.dxf.linetype   = LINETYPE


def draw(msp, lines: list):
    """
    Draw chain survey lines.
    These are the blue diagonal lines crossing the parcel.
    
    Args:
        msp:   modelspace
        lines: list of {x1,y1,x2,y2} — blue lines from PDF
    """
    count = 0
    for l in lines:
        pl = msp.add_lwpolyline(
            [(l["x1"], l["y1"]), (l["x2"], l["y2"])],
            dxfattribs={
                "layer":      LAYER_NAME,
                "color":      COLOR,
                "lineweight": LINEWEIGHT,
            }
        )
        pl.closed = False
        count += 1

    print(f"   WELL and BUILDING: {count} chain segments drawn")
