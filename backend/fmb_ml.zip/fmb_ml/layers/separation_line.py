"""
layers/separation_line.py — S.F.SEPERATION LINE Layer
Draws tick marks at boundary corner points A,B,C,D,E,F,G,H.

Verified from manual DXF:
  Layer name: S.F.SEPERATION LINE
  Color:      7 (White) — ByLayer
  Lineweight: 0
  Linetype:   Continuous
  Length:     ~21m each, extending outward from corner
  Count:      5 ticks in FMB 405 (at corners A,B,C,E,H)

Purpose:
  Each tick extends perpendicular to boundary at corner point.
  Marks the exact survey corner location.
"""

LAYER_NAME = "S.F.SEPERATION LINE"
COLOR      = 256    # ByLayer (white = 7 via layer)
LINEWEIGHT = 0
LINETYPE   = "Continuous"


def setup_layer(doc):
    """Register separation line layer"""
    layer = doc.layers.add(LAYER_NAME)
    layer.dxf.color      = 7    # White
    layer.dxf.lineweight = LINEWEIGHT
    layer.dxf.linetype   = LINETYPE


def draw(msp, lines: list):
    """
    Draw corner tick marks.
    These are the short lines extending outward from boundary corners.
    
    Args:
        msp:   modelspace
        lines: list of {x1,y1,x2,y2} — short lines at corners
    """
    count = 0
    for l in lines:
        pl = msp.add_lwpolyline(
            [(l["x1"], l["y1"]), (l["x2"], l["y2"])],
            dxfattribs={
                "layer":      LAYER_NAME,
                "color":      COLOR,
                "lineweight": LINEWEIGHT,
            }
        )
        pl.closed = False
        count += 1

    print(f"   S.F.SEPERATION LINE: {count} ticks drawn")
