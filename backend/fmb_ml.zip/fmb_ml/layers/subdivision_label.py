"""
layers/subdivision_label.py — SUB DIVISION NUMBER Layer
Draws area labels for each sub-division section.

Verified from manual DXF:
  Layer name: SUB DIVISION NUMBER
  Color:      130 (Teal/Cyan) — ByLayer
  Lineweight: 0
  Linetype:   Continuous
  Height:     4.0m
  Count:      4 text entities in FMB 405

  Examples from manual:
    1    2A    2B    3
"""

LAYER_NAME = "SUB DIVISION NUMBER"
COLOR      = 256    # ByLayer (teal = 130 via layer)
LINEWEIGHT = 0
LINETYPE   = "Continuous"
HEIGHT     = 4.0


def setup_layer(doc):
    """Register SUB DIVISION NUMBER layer"""
    layer = doc.layers.add(LAYER_NAME)
    layer.dxf.color      = 130   # Teal/Cyan
    layer.dxf.lineweight = LINEWEIGHT
    layer.dxf.linetype   = LINETYPE


def draw(msp, texts: list, ph: float, pt_m: float):
    """
    Draw subdivision area labels (1, 2A, 2B, 3).
    Placed in center of each sub-division area.
    
    Args:
        msp:   modelspace
        texts: OCR results filtered to type='subdivision_label'
        ph:    page height for Y flip
        pt_m:  scale factor
    """
    count = 0
    seen  = set()

    for t in texts:
        if t.get("type") != "subdivision_label":
            continue
        txt = str(t.get("text", "")).strip()
        x   = float(t.get("x", 0)) * pt_m
        y   = (ph - float(t.get("y", 0))) * pt_m

        key = (txt, round(x, 0), round(y, 0))
        if key in seen or not txt:
            continue
        seen.add(key)

        msp.add_text(txt, dxfattribs={
            "insert":  (x, y),
            "height":  HEIGHT,
            "layer":   LAYER_NAME,
            "color":   COLOR,
        })
        count += 1

    print(f"   SUB DIVISION NUMBER: {count} labels drawn")
