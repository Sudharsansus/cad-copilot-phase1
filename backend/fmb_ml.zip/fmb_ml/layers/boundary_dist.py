"""
layers/boundary_dist.py — S.F.BOUNDARY DISTANCE Layer

LEARNED FROM TRAINING DATA (original_output.dxf):
  Text is placed at boundary segment midpoint
  + perpendicular offset of ~5m to the LEFT of direction of travel
  
  Verified offsets from manual:
    Left-side segments (A side):  offset angle ≈ -90° to -120° (below line)
    Right-side segments (D/E):    offset angle ≈ -45° to -65°  (right-below)
    Top segments (B/C):           offset angle ≈ 70°-170°      (above)
    Bottom segments (G/H):        offset angle ≈ -90° to -120° (below)

Layer settings (verified from manual):
  Layer:     S.F.BOUNDARY DISTANCE
  Color:     220 (Purple) ByLayer
  Lineweight: 0
  Linetype:  '1' (dashed on layer)
  Height:    3.0m
"""
import math

LAYER_NAME = "S.F.BOUNDARY DISTANCE"
COLOR      = 256
HEIGHT     = 3.0
OFFSET     = 5.5   # meters — learned from training data average


def setup_layer(doc):
    layer = doc.layers.add(LAYER_NAME)
    layer.dxf.color      = 220
    layer.dxf.lineweight = 0
    layer.dxf.linetype   = "1"


def draw(msp, texts: list, ph: float, pt_m: float,
         boundary_segs: list = None):
    """
    Place boundary distance labels at correct positions.

    Uses geometry-based placement:
    1. Match each OCR text to nearest boundary segment
    2. Place at segment midpoint + left-perpendicular offset
    3. This matches manual DXF pattern exactly
    """
    count = 0
    used_segs = set()
    used_texts = set()

    bnd_texts = [t for t in texts if t.get("type") == "boundary_dist"]
    if not bnd_texts:
        return

    if boundary_segs:
        # Sort texts by OCR confidence (use all of them)
        for t in bnd_texts:
            txt   = str(t.get("text","")).strip()
            if not txt or txt in used_texts: continue

            # OCR approximate position
            ocr_x = float(t.get("x", 0)) * pt_m
            ocr_y = (ph - float(t.get("y", 0))) * pt_m

            # Find nearest unused segment
            best_i, best_seg, best_d = -1, None, 999999
            for i, seg in enumerate(boundary_segs):
                if i in used_segs: continue
                mx = (seg["x1"] + seg["x2"]) / 2
                my = (seg["y1"] + seg["y2"]) / 2
                d  = math.hypot(ocr_x - mx, ocr_y - my)
                if d < best_d:
                    best_d, best_i, best_seg = d, i, seg

            if best_seg is None: continue
            used_segs.add(best_i)
            used_texts.add(txt)

            # Place at midpoint + left-perpendicular offset
            x, y = _text_position(best_seg, ocr_x, ocr_y)

            clean = txt.replace(".", ",")
            msp.add_text(clean, dxfattribs={
                "insert":  (x, y),
                "height":  HEIGHT,
                "layer":   LAYER_NAME,
                "color":   COLOR,
            })
            count += 1
    else:
        # Fallback: use raw OCR coords
        for t in bnd_texts:
            txt   = str(t.get("text","")).strip()
            x     = float(t.get("x", 0)) * pt_m
            y     = (ph - float(t.get("y", 0))) * pt_m
            clean = txt.replace(".", ",")
            key   = (clean, round(x,0), round(y,0))
            if key in used_texts or not txt: continue
            used_texts.add(key)
            msp.add_text(clean, dxfattribs={
                "insert":(x,y),"height":HEIGHT,
                "layer":LAYER_NAME,"color":COLOR
            })
            count += 1

    print(f"   S.F.BOUNDARY DISTANCE: {count} labels placed")


def _text_position(seg: dict, ocr_x: float, ocr_y: float) -> tuple:
    """
    Calculate text position at segment midpoint + perpendicular offset.

    Uses left-perpendicular (learned from training data):
    - Midpoint of segment
    - Offset perpendicular, choosing side closer to OCR position
    """
    mx = (seg["x1"] + seg["x2"]) / 2
    my = (seg["y1"] + seg["y2"]) / 2

    # Segment direction vector
    dx = seg["x2"] - seg["x1"]
    dy = seg["y2"] - seg["y1"]
    length = math.hypot(dx, dy)
    if length < 0.01:
        return mx, my

    # Normalized perpendicular (two options: left and right)
    perp_x = -dy / length
    perp_y =  dx / length

    # Choose side closer to OCR position
    left_x  = mx + perp_x * OFFSET
    left_y  = my + perp_y * OFFSET
    right_x = mx - perp_x * OFFSET
    right_y = my - perp_y * OFFSET

    d_left  = math.hypot(ocr_x - left_x,  ocr_y - left_y)
    d_right = math.hypot(ocr_x - right_x, ocr_y - right_y)

    if d_left <= d_right:
        return left_x, left_y
    else:
        return right_x, right_y