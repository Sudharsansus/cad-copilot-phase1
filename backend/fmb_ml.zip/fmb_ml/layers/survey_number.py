"""
layers/survey_number.py — SURVEY NUMBER Layer
SF numbers and corner labels.

Verified from manual DXF:
  Layer: SURVEY NUMBER
  Color: 6 (Magenta) via layer, entities ByLayer(256)
  Height: 5.0m for SF numbers, 2.0m for corner labels
  
  Contains:
  - Own SF number (405) → center of parcel, h=5.0
  - Neighbor SF numbers (400,403,416,417,612) → outside, h=5.0
  - Corner labels A,B,C,D,E,F,G,H → at corners, h=2.0
"""

LAYER_NAME          = "SURVEY NUMBER"
COLOR               = 256   # ByLayer → magenta(6) from layer
HEIGHT_SF_NUMBER    = 5.0
HEIGHT_CORNER_LABEL = 2.0


def setup_layer(doc):
    layer = doc.layers.add(LAYER_NAME)
    layer.dxf.color      = 6    # Magenta
    layer.dxf.lineweight = 0
    layer.dxf.linetype   = "Continuous"


def draw_sf_numbers(msp, texts: list, ph: float, pt_m: float):
    """Neighbor SF numbers: 400, 403, 416, 417, 612"""
    count = 0
    seen  = set()
    for t in texts:
        if t.get("type") != "survey_number": continue
        txt = str(t.get("text","")).strip()
        x   = float(t.get("x",0)) * pt_m
        y   = (ph - float(t.get("y",0))) * pt_m
        key = (txt, round(x,0), round(y,0))
        if key in seen or not txt: continue
        seen.add(key)
        msp.add_text(txt, dxfattribs={
            "insert":(x,y), "height":HEIGHT_SF_NUMBER,
            "layer":LAYER_NAME, "color":COLOR
        })
        count += 1
    print(f"   SURVEY NUMBER (neighbors): {count}")


def draw_corner_labels(msp, texts: list, ph: float, pt_m: float):
    """Corner labels A,B,C,D,E,F,G,H"""
    count = 0
    seen  = set()
    for t in texts:
        if t.get("type") != "corner_label": continue
        txt = str(t.get("text","")).strip()
        x   = float(t.get("x",0)) * pt_m
        y   = (ph - float(t.get("y",0))) * pt_m
        key = (txt, round(x,0), round(y,0))
        if key in seen or not txt: continue
        seen.add(key)
        msp.add_text(txt, dxfattribs={
            "insert":(x,y), "height":HEIGHT_CORNER_LABEL,
            "layer":LAYER_NAME, "color":COLOR
        })
        count += 1
    print(f"   SURVEY NUMBER (corners): {count}")


def draw_own_sf(msp, sf_no: str, lines: list):
    """
    Draw own SF number (405) in center of parcel.
    Calculated from average of all boundary line midpoints.
    """
    if not sf_no or sf_no == "?" or not lines:
        return
    cx = sum((l["x1"]+l["x2"])/2 for l in lines) / len(lines)
    cy = sum((l["y1"]+l["y2"])/2 for l in lines) / len(lines)
    msp.add_text(sf_no, dxfattribs={
        "insert":(cx, cy), "height":HEIGHT_SF_NUMBER,
        "layer":LAYER_NAME, "color":COLOR
    })
    print(f"   SURVEY NUMBER (own {sf_no}): center ({cx:.1f},{cy:.1f})")