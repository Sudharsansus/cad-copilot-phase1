"""
layers/subdivision_dist.py — SUB DIVISION LINE DISTANCE Layer

LEARNED FROM TRAINING DATA:
  Text placed at subdivision line midpoint + offset
  
Layer settings (verified from manual):
  Layer:     SUB DIVISION LINE DISTANCE
  Color:     200 (Pink) ByLayer
  Lineweight: 0
  Linetype:  '1' (dashed on layer)
  Height:    3.0m
"""
import math

LAYER_NAME = "SUB DIVISION LINE DISTANCE"
COLOR      = 256
HEIGHT     = 3.0
OFFSET     = 4.0


def setup_layer(doc):
    layer = doc.layers.add(LAYER_NAME)
    layer.dxf.color      = 200
    layer.dxf.lineweight = 0
    layer.dxf.linetype   = "1"


def draw(msp, texts: list, ph: float, pt_m: float,
         subdivision_segs: list = None):
    """Place subdivision distance labels near subdivision lines."""
    count    = 0
    used_segs= set()
    used_txt = set()

    sub_texts = [t for t in texts if t.get("type") == "subdivision_dist"]
    if not sub_texts:
        return

    for t in sub_texts:
        txt   = str(t.get("text","")).strip()
        if not txt or txt in used_txt: continue

        ocr_x = float(t.get("x",0)) * pt_m
        ocr_y = (ph - float(t.get("y",0))) * pt_m

        if subdivision_segs:
            # Find nearest unused subdivision segment
            best_i, best_seg, best_d = -1, None, 999999
            for i, seg in enumerate(subdivision_segs):
                if i in used_segs: continue
                mx = (seg["x1"]+seg["x2"])/2
                my = (seg["y1"]+seg["y2"])/2
                d  = math.hypot(ocr_x-mx, ocr_y-my)
                if d < best_d:
                    best_d, best_i, best_seg = d, i, seg

            if best_seg:
                used_segs.add(best_i)
                x, y = _offset_position(best_seg, ocr_x, ocr_y)
            else:
                x, y = ocr_x, ocr_y
        else:
            x, y = ocr_x, ocr_y

        used_txt.add(txt)
        clean = txt.replace(".", ",")
        msp.add_text(clean, dxfattribs={
            "insert":(x,y), "height":HEIGHT,
            "layer":LAYER_NAME, "color":COLOR
        })
        count += 1

    print(f"   SUB DIVISION LINE DISTANCE: {count} labels placed")


def _offset_position(seg, ocr_x, ocr_y):
    mx = (seg["x1"]+seg["x2"])/2
    my = (seg["y1"]+seg["y2"])/2
    dx = seg["x2"]-seg["x1"]
    dy = seg["y2"]-seg["y1"]
    length = math.hypot(dx, dy)
    if length < 0.01: return mx, my
    perp_x = -dy/length
    perp_y =  dx/length
    lx,ly = mx+perp_x*OFFSET, my+perp_y*OFFSET
    rx,ry = mx-perp_x*OFFSET, my-perp_y*OFFSET
    if math.hypot(ocr_x-lx,ocr_y-ly) <= math.hypot(ocr_x-rx,ocr_y-ry):
        return lx, ly
    return rx, ry