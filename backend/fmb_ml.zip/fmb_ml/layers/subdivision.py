"""
layers/subdivision.py — SUB DIVISION Layer
Internal lines dividing parcel into sections.

Verified from manual DXF:
  Layer: SUB DIVISION
  Color: 3 (Green) via layer, entities use ByLayer(256)
  Lineweight: 0
  Linetype: '1' on LAYER, entities use ByLayer
  Count: 5 lines in FMB 405
"""

LAYER_NAME = "SUB DIVISION"
COLOR      = 256   # ByLayer → green(3) from layer
LINEWEIGHT = 0
LINETYPE   = "1"   # dashed on layer definition


def setup_layer(doc):
    layer = doc.layers.add(LAYER_NAME)
    layer.dxf.color      = 3      # Green
    layer.dxf.lineweight = LINEWEIGHT
    layer.dxf.linetype   = LINETYPE


def draw(msp, lines: list):
    """
    Draw subdivision lines — green, ByLayer linetype.
    Entities use ByLayer so they inherit dashed from layer.
    """
    count = 0
    for l in lines:
        pl = msp.add_lwpolyline(
            [(l["x1"], l["y1"]), (l["x2"], l["y2"])],
            dxfattribs={
                "layer":      LAYER_NAME,
                "color":      COLOR,       # ByLayer
                "lineweight": LINEWEIGHT,
            }
        )
        pl.closed = False
        count += 1
    print(f"   SUB DIVISION: {count} lines drawn")