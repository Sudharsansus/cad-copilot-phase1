"""
layers/chain_point.py — S.F.SEPERATION LINE (text part)
Draws chain point numbers on boundary.

Verified from manual DXF:
  Layer name: S.F.SEPERATION LINE
  Color:      7 (White) — ByLayer
  Height:     2.0m
  Numbers:    11, 12, 13, 14, 16, 18 (red in PDF)

  These are the points where chain survey lines
  meet the boundary line.
"""

LAYER_NAME = "S.F.SEPERATION LINE"
COLOR      = 256    # ByLayer (white = 7 via layer)
HEIGHT     = 2.0


def draw(msp, texts: list, ph: float, pt_m: float):
    """
    Draw chain point number labels (11, 12, 13, 14, 16, 18).
    These mark where chain lines intersect the boundary.
    
    Args:
        msp:   modelspace
        texts: OCR results filtered to type='chain_point'
        ph:    page height for Y flip
        pt_m:  scale factor
    """
    count = 0
    seen  = set()

    for t in texts:
        if t.get("type") != "chain_point":
            continue
        txt = str(t.get("text", "")).strip()
        x   = float(t.get("x", 0)) * pt_m
        y   = (ph - float(t.get("y", 0))) * pt_m

        key = (txt, round(x, 0), round(y, 0))
        if key in seen or not txt:
            continue
        seen.add(key)

        msp.add_text(txt, dxfattribs={
            "insert":  (x, y),
            "height":  HEIGHT,
            "layer":   LAYER_NAME,
            "color":   COLOR,
        })
        count += 1

    print(f"   Chain points: {count} labels drawn")
