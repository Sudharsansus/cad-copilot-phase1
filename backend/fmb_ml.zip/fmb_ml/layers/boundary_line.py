"""
layers/boundary_line.py — BOUNDARY LINE Layer
Outer polygon — RED thick lines.

Verified from manual DXF:
  Layer: boundry line (typo kept intentional)
  Color: 1 (RED) — explicit on entity AND layer
  Lineweight: 70 (0.70mm) — explicit on entity
  Linetype: Continuous
  Each segment = separate 2-point LWPOLYLINE
"""

LAYER_NAME = "boundry line"
COLOR      = 1     # RED — explicit
LINEWEIGHT = 70    # 0.70mm
LINETYPE   = "Continuous"


def setup_layer(doc):
    layer = doc.layers.add(LAYER_NAME)
    layer.dxf.color      = COLOR
    layer.dxf.lineweight = LINEWEIGHT
    layer.dxf.linetype   = LINETYPE


def draw(msp, lines: list):
    """
    Draw each boundary segment as separate 2-pt LWPOLYLINE.
    Color=1(RED) and lineweight=70 set explicitly.
    """
    count = 0
    for l in lines:
        pl = msp.add_lwpolyline(
            [(l["x1"], l["y1"]), (l["x2"], l["y2"])],
            dxfattribs={
                "layer":      LAYER_NAME,
                "color":      COLOR,       # RED explicit
                "lineweight": LINEWEIGHT,  # 0.70mm explicit
            }
        )
        pl.closed = False
        count += 1
    print(f"   boundry line: {count} segments drawn")