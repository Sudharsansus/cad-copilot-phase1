"""
extractor.py — FMB PDF Vector Line Extractor
Uses PATH-level classification (not item-level).

Key insight from pymupdf docs:
  get_drawings() returns PATHS — each path is one logical element
  with shared width, color, and all its connected line segments.

Classification (verified FMB 405 + FMB 252):
  PATH w=3.0, black, total>10m → boundary line
  PATH w=3.0, black, total≤10m → separation tick
  PATH w=1.0, blue             → WELL and BUILDING (chain survey)
  PATH w=1.0, black, not dup   → subdivision line
  PATH w=1.0, black, duplicate → skip (duplicate of boundary)
  PATH w=0.0                   → text characters (skip)
  gray color (0.25...)         → page border (skip)
"""
import fitz
import math
from scale import get_scale_factor, detect_scale_from_page


def extract(pdf_bytes: bytes) -> tuple:
    """Main extraction. Returns (classified_lines, page_info, img_bytes)"""
    doc  = fitz.open(stream=pdf_bytes, filetype="pdf")
    page = doc[0]
    ph   = page.rect.height
    pw   = page.rect.width

    scale = detect_scale_from_page(page)
    pt_m  = get_scale_factor(scale)

    img_bytes  = _render_image(page)
    classified = _classify_paths(page, pw, ph, pt_m)

    page_info = {
        "height":  ph, "width": pw,
        "scale":   scale, "pt_to_m": pt_m,
    }
    return classified, page_info, img_bytes


def _render_image(page) -> bytes:
    pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))
    return pix.tobytes("png")


def _is_page_border(rect, pw, ph) -> bool:
    if rect is None: return False
    return rect.width > pw * 0.8 or rect.height > ph * 0.8


def _is_gray(color) -> bool:
    if not color or not isinstance(color, tuple): return False
    return all(abs(v - 0.25) < 0.05 for v in color)


def _path_lines(path) -> list:
    return [it for it in path.get("items", []) if it[0] == "l"]


def _path_total_length(lines, pt_m) -> float:
    return sum(
        math.hypot(it[2].x-it[1].x, it[2].y-it[1].y) * pt_m
        for it in lines
    )


def _to_segments(lines, ph, pt_m) -> list:
    result = []
    for it in lines:
        p1, p2 = it[1], it[2]
        x1, y1 = p1.x*pt_m, (ph-p1.y)*pt_m
        x2, y2 = p2.x*pt_m, (ph-p2.y)*pt_m
        lenm   = math.hypot(p2.x-p1.x, p2.y-p1.y) * pt_m
        result.append({"x1":x1,"y1":y1,"x2":x2,"y2":y2,"lenm":lenm})
    return result


def _classify_paths(page, pw, ph, pt_m) -> dict:
    boundary   = []
    separation = []
    chain      = []
    subdivision= []

    # Pass 1: collect boundary endpoints for duplicate detection
    bnd_pts = set()
    for path in page.get_drawings():
        w     = path.get("width") or 0
        color = path.get("color")
        lines = _path_lines(path)
        if not lines or _is_gray(color): continue
        if _is_page_border(path.get("rect"), pw, ph): continue
        total = _path_total_length(lines, pt_m)
        if abs(w-3.0)<0.5 and color==(0.,0.,0.) and total>10:
            for it in lines:
                bnd_pts.add((round(it[1].x), round(it[1].y)))
                bnd_pts.add((round(it[2].x), round(it[2].y)))

    # Pass 2: classify each path
    for path in page.get_drawings():
        w     = path.get("width") or 0
        color = path.get("color")
        lines = _path_lines(path)
        if not lines or _is_gray(color): continue
        if _is_page_border(path.get("rect"), pw, ph): continue

        total = _path_total_length(lines, pt_m)
        segs  = _to_segments(lines, ph, pt_m)

        # BOUNDARY: thickest black lines
        if abs(w-3.0)<0.5 and color==(0.,0.,0.):
            if total > 10:
                boundary.extend(segs)
            else:
                # Short w=3: check if BOTH endpoints connect to boundary
                # If yes → boundary connector (like 1.9m B→C gap)
                # If no  → separation tick (extends outward)
                both_on_bnd = all(
                    (round(it[1].x),round(it[1].y)) in bnd_pts and
                    (round(it[2].x),round(it[2].y)) in bnd_pts
                    for it in _path_lines(path)
                )
                if both_on_bnd:
                    boundary.extend(segs)
                else:
                    separation.extend(segs)
            continue

        # CHAIN: blue lines (WELL and BUILDING)
        if abs(w-1.0)<0.5 and color==(0.,0.,1.):
            chain.extend([s for s in segs if s["lenm"] > 5])
            continue

        # SUBDIVISION: thin black non-duplicate lines
        if abs(w-1.0)<0.5 and color==(0.,0.,0.):
            is_dup = True
            for it in lines:
                k1=(round(it[1].x), round(it[1].y))
                k2=(round(it[2].x), round(it[2].y))
                if k1 not in bnd_pts or k2 not in bnd_pts:
                    is_dup = False
                    break
            if not is_dup:
                subdivision.extend(segs)
            continue

    print(f"   boundary={len(boundary)} separation={len(separation)} "
          f"chain={len(chain)} subdivision={len(subdivision)}")

    return {
        "boundary":    boundary,
        "separation":  separation,
        "chain":       chain,
        "subdivision": subdivision,
    }