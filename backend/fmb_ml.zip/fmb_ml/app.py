"""
app.py - FMB ML Converter Web App
Upload PDF → AI converts → Download DXF
"""
import os, io, uuid, traceback
from flask import Flask, request, jsonify, send_file, render_template_string
from ml_pipeline import convert_fmb, load_stats as load_training_stats

app   = Flask(__name__)
store = {}

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
GEMINI_API_KEY    = os.environ.get("GEMINI_API_KEY", "")

HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>FMB AI Converter</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#05050a;--card:#0e0e18;--border:#1a1a2e;
  --accent:#7c5cfc;--green:#00d4aa;--red:#ff4466;
  --text:#e0e0f0;--muted:#5a5a7a;
}
body{background:var(--bg);color:var(--text);font-family:'Space Grotesk',sans-serif;min-height:100vh}

/* Header */
.header{
  padding:20px 40px;border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:16px;
  background:linear-gradient(135deg,#05050a,#0a0a16)
}
.logo{
  width:44px;height:44px;border-radius:12px;
  background:linear-gradient(135deg,var(--accent),var(--green));
  display:grid;place-items:center;
  font-family:'JetBrains Mono',monospace;font-weight:700;font-size:14px
}
.title{font-size:18px;font-weight:700}
.sub{color:var(--muted);font-size:12px;margin-top:2px}
.ai-badge{
  margin-left:auto;background:rgba(124,92,252,.15);
  border:1px solid rgba(124,92,252,.3);
  color:var(--accent);padding:6px 14px;border-radius:20px;
  font-size:12px;font-weight:600;display:flex;align-items:center;gap:6px
}
.ai-dot{width:6px;height:6px;border-radius:50%;background:var(--accent);
        box-shadow:0 0 8px var(--accent);animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}

/* Stats bar */
.stats-bar{
  padding:12px 40px;background:rgba(0,212,170,.05);
  border-bottom:1px solid rgba(0,212,170,.1);
  display:flex;gap:32px;font-size:13px
}
.stat-item{display:flex;align-items:center;gap:8px;color:var(--muted)}
.stat-val{color:var(--green);font-weight:600;font-family:'JetBrains Mono',monospace}

/* Main */
main{max-width:720px;margin:48px auto;padding:0 20px}

/* Upload */
.upload-card{
  background:var(--card);border:1px solid var(--border);
  border-radius:16px;padding:40px;margin-bottom:24px
}
.zone{
  border:2px dashed var(--border);border-radius:12px;
  padding:48px 30px;text-align:center;cursor:pointer;
  transition:all .2s;position:relative
}
.zone:hover,.zone.drag{
  border-color:var(--accent);
  background:rgba(124,92,252,.05)
}
.zone input{position:absolute;inset:0;opacity:0;cursor:pointer;z-index:2}
.zone-icon{font-size:44px;margin-bottom:16px}
.zone-title{font-size:20px;font-weight:700;margin-bottom:8px}
.zone-sub{color:var(--muted);font-size:14px;margin-bottom:20px;line-height:1.7}
.btn-primary{
  padding:12px 28px;border-radius:10px;border:none;
  background:linear-gradient(135deg,var(--accent),#9b7dff);
  color:#fff;font-size:14px;font-weight:600;
  cursor:pointer;font-family:inherit;
  box-shadow:0 4px 20px rgba(124,92,252,.3);transition:all .15s
}
.btn-primary:hover{transform:translateY(-1px);box-shadow:0 6px 28px rgba(124,92,252,.45)}
.btn-primary:disabled{opacity:.4;cursor:not-allowed;transform:none}

/* File info */
#file-info{
  display:none;margin-top:16px;padding:14px 18px;
  background:var(--bg);border:1px solid var(--border);border-radius:10px;
  display:flex;align-items:center;gap:12px
}
.fname{flex:1;font-family:'JetBrains Mono',monospace;font-size:13px}
.fsize{color:var(--muted);font-size:12px}

/* Convert btn */
#convert-btn{width:100%;margin-top:20px;padding:16px;font-size:16px;letter-spacing:.3px}

/* Progress */
.progress{margin-top:16px;display:none}
.steps{display:flex;flex-direction:column;gap:8px}
.step{
  display:flex;align-items:center;gap:12px;
  padding:10px 14px;border-radius:8px;
  background:var(--bg);border:1px solid var(--border);
  font-size:13px;color:var(--muted);transition:all .3s
}
.step.active{border-color:var(--accent);color:var(--text);background:rgba(124,92,252,.05)}
.step.done{border-color:var(--green);color:var(--green);background:rgba(0,212,170,.05)}
.step-icon{font-size:16px;width:24px;text-align:center}
.spinner{
  width:16px;height:16px;border:2px solid rgba(124,92,252,.3);
  border-top-color:var(--accent);border-radius:50%;
  animation:spin .8s linear infinite
}
@keyframes spin{to{transform:rotate(360deg)}}

/* Result */
#result{display:none;margin-top:24px}
.result-card{
  background:var(--card);border:1px solid var(--border);
  border-radius:14px;padding:24px;border-left:3px solid var(--green)
}
.result-title{font-size:20px;font-weight:700;color:var(--accent);margin-bottom:4px}
.result-sub{color:var(--muted);font-size:13px;margin-bottom:20px}
.result-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:20px}
.rg-item{background:var(--bg);border-radius:8px;padding:12px}
.rg-label{font-size:10px;text-transform:uppercase;letter-spacing:1px;color:var(--muted);margin-bottom:4px}
.rg-val{font-family:'JetBrains Mono',monospace;font-size:15px;font-weight:700}
.layers{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:20px}
.layer{font-size:11px;font-family:'JetBrains Mono',monospace;
       padding:3px 9px;border-radius:4px;border:1px solid}
.l-r{color:#ff6680;border-color:#ff446630}
.l-g{color:#00d4aa;border-color:#00d4aa30}
.l-b{color:#6aabff;border-color:#6aabff30}
.l-y{color:#f5c518;border-color:#f5c51830}
.l-w{color:#ccc;border-color:#ccc3}
.l-p{color:#c088ff;border-color:#c088ff30}
.btn-dl{
  width:100%;padding:14px;border:none;border-radius:10px;
  background:var(--green);color:#000;font-size:15px;font-weight:700;
  cursor:pointer;font-family:inherit;transition:transform .15s
}
.btn-dl:hover{transform:translateY(-1px)}

/* Error */
#error{
  display:none;margin-top:16px;padding:14px;
  background:#1a0508;border:1px solid var(--red);
  border-radius:10px;color:var(--red);font-size:13px
}
</style>
</head>
<body>
<div class="header">
  <div class="logo">FMB</div>
  <div>
    <div class="title">FMB AI Converter</div>
    <div class="sub">Tamil Nadu Survey Department · PDF → DXF</div>
  </div>
  <div class="ai-badge"><div class="ai-dot"></div>AI Powered</div>
</div>

<div class="stats-bar">
  <div class="stat-item">
    🧠 <span>Total Conversions:</span>
    <span class="stat-val" id="stat-total">{{ stats.total_conversions }}</span>
  </div>
  <div class="stat-item">
    📍 <span>Districts Learned:</span>
    <span class="stat-val" id="stat-dist">{{ stats.districts|length }}</span>
  </div>
  <div class="stat-item">
    ✅ <span>Accuracy:</span>
    <span class="stat-val" id="stat-ocr">
        {% if anthropic_key %}Claude Vision{% elif gemini_key %}Gemini{% else %}Tesseract{% endif %}
        </span>
  </div>
</div>

<main>
  <div class="upload-card">
    <div class="zone" id="zone">
      <input type="file" id="file-input" accept=".pdf">
      <div class="zone-icon">📐</div>
      <div class="zone-title">Upload FMB PDF</div>
      <div class="zone-sub">
        Government FMB PDF from eservices.tn.gov.in<br>
        AI reads all measurements · Converts to exact DXF · Learns from every file
      </div>
      <button class="btn-primary"
        onclick="event.stopPropagation();document.getElementById('file-input').click()">
        Select PDF
      </button>
    </div>

    <div id="file-info" style="display:none">
      <span style="font-size:20px">📄</span>
      <span class="fname" id="fname"></span>
      <span class="fsize" id="fsize"></span>
    </div>

    <button class="btn-primary" id="convert-btn" disabled onclick="convert()">
      🧠 Convert with AI →
    </button>

    <div class="progress" id="progress">
      <div class="steps">
        <div class="step" id="s1"><span class="step-icon">🔍</span>Extracting vectors from PDF...</div>
        <div class="step" id="s2"><span class="step-icon">🧠</span>Claude Vision reading measurements...</div>
        <div class="step" id="s3"><span class="step-icon">📐</span>Classifying boundary & subdivision lines...</div>
        <div class="step" id="s4"><span class="step-icon">📝</span>Building DXF with correct layers...</div>
        <div class="step" id="s5"><span class="step-icon">💾</span>Saving to training data...</div>
      </div>
    </div>

    <div id="error"></div>
  </div>

  <div id="result">
    <div class="result-card">
      <div class="result-title" id="r-sf"></div>
      <div class="result-sub" id="r-loc"></div>
      <div class="result-grid">
        <div class="rg-item">
          <div class="rg-label">Scale</div>
          <div class="rg-val" id="r-scale"></div>
        </div>
        <div class="rg-item">
          <div class="rg-label">Lines</div>
          <div class="rg-val" id="r-lines"></div>
        </div>
        <div class="rg-item">
          <div class="rg-label">Text Labels</div>
          <div class="rg-val" id="r-texts"></div>
        </div>
      </div>
      <div class="layers">
        <span class="layer l-r">boundry line</span>
        <span class="layer l-w">S.F.SEPERATION LINE</span>
        <span class="layer l-b">WELL and BUILDING</span>
        <span class="layer l-g">SUB DIVISION</span>
        <span class="layer l-y">S.F.BOUNDARY DISTANCE</span>
        <span class="layer l-w">CHAIN LINE DISTANCE</span>
        <span class="layer l-p">SUB DIVISION NUMBER</span>
        <span class="layer l-p">SURVEY NUMBER</span>
      </div>
      <button class="btn-dl" onclick="dl()">⬇ Download DXF</button>
    </div>
  </div>
</main>

<script>
let file=null, dxf_id=null;
const zone=document.getElementById('zone');
const input=document.getElementById('file-input');
const btn=document.getElementById('convert-btn');
const prog=document.getElementById('progress');
const err=document.getElementById('error');
const res=document.getElementById('result');

zone.addEventListener('dragover',e=>{e.preventDefault();zone.classList.add('drag')});
zone.addEventListener('dragleave',()=>zone.classList.remove('drag'));
zone.addEventListener('drop',e=>{e.preventDefault();zone.classList.remove('drag');
  const f=e.dataTransfer.files[0]; if(f&&f.name.endsWith('.pdf')) setFile(f)});
input.addEventListener('change',()=>{if(input.files[0]) setFile(input.files[0])});

function setFile(f){
  file=f;
  document.getElementById('fname').textContent=f.name;
  document.getElementById('fsize').textContent=(f.size/1024).toFixed(0)+' KB';
  document.getElementById('file-info').style.display='flex';
  btn.disabled=false; err.style.display='none'; res.style.display='none';
}

function setStep(n, done=false){
  for(let i=1;i<=5;i++){
    const el=document.getElementById('s'+i);
    el.className='step'+(i===n&&!done?' active':i<n||done?' done':'');
    if(i===n&&!done){
      const icon=el.querySelector('.step-icon');
      const spinner=document.createElement('div');
      spinner.className='spinner';
      icon.replaceWith(spinner);
    }
  }
}

async function convert(){
  if(!file) return;
  btn.disabled=true;
  prog.style.display='block';
  err.style.display='none';
  res.style.display='none';

  // Simulate step progress
  setStep(1);
  const fd=new FormData(); fd.append('pdf',file);

  try{
    // Start request
    setTimeout(()=>setStep(2),800);
    setTimeout(()=>setStep(3),2000);
    setTimeout(()=>setStep(4),3500);
    setTimeout(()=>setStep(5),5000);

    const r=await fetch('/convert',{method:'POST',body:fd});
    const data=await r.json();

    if(data.ok){
      setStep(5,true);
      dxf_id=data.id;
      const inf=data.info;
      document.getElementById('r-sf').textContent='SF No. '+inf.sf_no;
      document.getElementById('r-loc').textContent=
        inf.district+' · '+inf.taluk+' · '+inf.village;
      document.getElementById('r-scale').textContent='1:'+inf.scale;
      document.getElementById('r-lines').textContent=inf.lines;
      document.getElementById('r-texts').textContent=inf.texts;
      res.style.display='block';
    } else {
      showErr(data.error);
    }
  } catch(e){ showErr(e.message); }
  finally{ btn.disabled=false; }
}

function showErr(msg){
  err.textContent='❌ '+msg; err.style.display='block';
  prog.style.display='none';
}

function dl(){
  const a=document.createElement('a');
  a.href='/download/'+dxf_id;
  a.download='FMB_SF'+document.getElementById('r-sf')
    .textContent.replace('SF No. ','')+'.dxf';
  a.click();
}
</script>
</body>
</html>"""


@app.route("/")
def index():
    stats = load_training_stats()
    return render_template_string(HTML, stats=stats)


@app.route("/convert", methods=["POST"])
def convert():
    try:
        pdf_bytes = request.files["pdf"].read()
        dxf_bytes, info = convert_fmb(pdf_bytes, ANTHROPIC_API_KEY or GEMINI_API_KEY)
        fid = str(uuid.uuid4())
        store[fid] = dxf_bytes
        return jsonify({"ok": True, "id": fid, "info": info})
    except Exception as e:
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)})


@app.route("/download/<fid>")
def download(fid):
    b = store.get(fid)
    if not b: return "Not found", 404
    return send_file(io.BytesIO(b), mimetype="application/octet-stream",
                     as_attachment=True, download_name="fmb_output.dxf")


@app.route("/stats")
def stats():
    return jsonify(load_training_stats())


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5050, debug=False)