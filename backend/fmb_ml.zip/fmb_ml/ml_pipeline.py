"""
ml_pipeline.py — FMB PDF to DXF ML Pipeline Orchestrator
Coordinates all modules to produce accurate DXF output.

Module structure:
  scale.py              → scale factor calculation
  extractor.py          → PDF vector line extraction
  ocr.py                → Claude Vision / Tesseract OCR
  layers/
    boundary_line.py    → boundry line layer
    separation_line.py  → S.F.SEPERATION LINE layer
    chain_line.py       → WELL and BUILDING layer
    subdivision.py      → SUB DIVISION layer
    survey_number.py    → SURVEY NUMBER layer
    boundary_dist.py    → S.F.BOUNDARY DISTANCE layer
    chain_dist.py       → CHAIN LINE DISTANCE layer
    subdivision_dist.py → SUB DIVISION LINE DISTANCE layer
    subdivision_label.py→ SUB DIVISION NUMBER layer
    chain_point.py      → chain point labels
"""
import ezdxf
import json
import os
import re
import tempfile
import hashlib
from datetime import datetime
from pathlib import Path

from extractor import extract
from ocr       import extract_with_claude, extract_with_tesseract, extract_with_gemini

from layers import boundary_line
from layers import separation_line
from layers import chain_line
from layers import subdivision
from layers import survey_number
from layers import boundary_dist
from layers import chain_dist
from layers import subdivision_dist
from layers import subdivision_label
from layers import chain_point

# Self-learning storage
TRAINING_DIR = Path("training_data")
TRAINING_DIR.mkdir(exist_ok=True)

# Linetype '1' = dashed (used by several layers)
LINETYPE_DASHED = "1"


def convert_fmb(pdf_bytes: bytes, api_key: str = "") -> tuple:
    """
    Full ML pipeline: PDF bytes → DXF bytes

    Returns: (dxf_bytes, info_dict)
    """

    # ── Step 1: Extract vectors ───────────────────────────────────
    print("🔍 Step 1: Extracting vectors from PDF...")
    classified, page_info, img_bytes = extract(pdf_bytes)

    # ── Step 2: OCR text labels ───────────────────────────────────
    print("🧠 Step 2: Reading text labels...")
    anthropic_key = api_key if api_key else ""
    gemini_key    = os.environ.get("GEMINI_API_KEY", "")

    if anthropic_key:
        texts = extract_with_claude(img_bytes, anthropic_key)
        print(f"   Claude Vision: {len(texts)} labels")
    elif gemini_key:
        texts = extract_with_gemini(img_bytes, gemini_key)
        print(f"   Gemini 2.0 Flash: {len(texts)} labels")
    else:
        texts = extract_with_tesseract(img_bytes)
        print(f"   Tesseract: {len(texts)} labels")

    # ── Step 3: Build DXF ─────────────────────────────────────────
    print("📐 Step 3: Building DXF...")
    dxf_bytes = _build_dxf(classified, texts, page_info)

    # ── Step 4: Parse info ────────────────────────────────────────
    full  = " ".join(str(t.get("text","")) for t in texts)
    info  = _parse_header(full, page_info, classified, texts)

    # ── Step 5: Save training data ────────────────────────────────
    print("💾 Step 5: Saving training data...")
    _save_training(pdf_bytes, dxf_bytes, texts, info)

    stats = load_stats()
    print(f"   Model learned from {stats['total_conversions']} conversions")

    return dxf_bytes, info


def _build_dxf(classified: dict, texts: list, page_info: dict) -> bytes:
    """
    Assemble complete DXF from all components.
    Each layer handled by its dedicated module.
    """
    doc = ezdxf.new("R2013")
    msp = doc.modelspace()
    ph  = page_info["height"]
    pt_m= page_info["pt_to_m"]

    # Register dashed linetype
    doc.linetypes.add(
        LINETYPE_DASHED,
        pattern=[5.0, 2.5, -2.5],
        description="Dashed"
    )

    # Setup all layers
    boundary_line.setup_layer(doc)
    separation_line.setup_layer(doc)
    chain_line.setup_layer(doc)
    subdivision.setup_layer(doc)
    survey_number.setup_layer(doc)
    boundary_dist.setup_layer(doc)
    chain_dist.setup_layer(doc)
    subdivision_dist.setup_layer(doc)
    subdivision_label.setup_layer(doc)

    # Draw all lines
    boundary_line.draw(msp, classified["boundary"])
    separation_line.draw(msp, classified["separation"])
    chain_line.draw(msp, classified["chain"])
    subdivision.draw(msp, classified["subdivision"])

    # Draw all text labels
    survey_number.draw_sf_numbers(msp, texts, ph, pt_m)
    survey_number.draw_corner_labels(msp, texts, ph, pt_m)
    survey_number.draw_own_sf(msp, _parse_header(' '.join(str(t.get('text','')) for t in texts), page_info, classified, texts).get('sf_no','?'), classified['boundary'])
    boundary_dist.draw(msp, texts, ph, pt_m, classified['boundary'])
    chain_dist.draw(msp, texts, ph, pt_m)
    subdivision_dist.draw(msp, texts, ph, pt_m, classified['subdivision'])
    subdivision_label.draw(msp, texts, ph, pt_m)
    chain_point.draw(msp, texts, ph, pt_m)

    # Save to bytes
    tmp = os.path.join(tempfile.gettempdir(), "fmb_out.dxf")
    doc.saveas(tmp)
    with open(tmp, "rb") as f:
        return f.read()


def _parse_header(full_text: str, page_info: dict,
                  classified: dict, texts: list) -> dict:
    """Extract header info from OCR results"""
    def find(pattern):
        m = re.search(pattern, full_text, re.I)
        return m.group(1) if m else ""

    return {
        "sf_no":    find(r'Survey\s*No\s*[:\-]?\s*(\d+)') or "?",
        "district": find(r'District\s*[:\-]?\s*(\w+)'),
        "taluk":    find(r'Taluk\s*[:\-]?\s*(\w+)'),
        "village":  find(r'Village\s*[:\-]?\s*([\w.]+)'),
        "scale":    page_info["scale"],
        "lines":    sum(len(v) for v in classified.values()),
        "texts":    len(texts),
    }


def _save_training(pdf_bytes, dxf_bytes, texts, info):
    """Save conversion for self-learning"""
    pdf_hash = hashlib.md5(pdf_bytes).hexdigest()[:8]
    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    name     = f"FMB_{info.get('sf_no','?')}_{pdf_hash}_{ts}"

    with open(TRAINING_DIR / f"{name}.json", "w") as f:
        json.dump({**info, "texts": texts, "timestamp": ts}, f, indent=2)

    with open(TRAINING_DIR / f"{name}.dxf", "wb") as f:
        f.write(dxf_bytes)


def load_stats() -> dict:
    """Load self-learning statistics"""
    records   = list(TRAINING_DIR.glob("*.json"))
    districts = set()
    for r in records:
        try:
            with open(r) as f:
                districts.add(json.load(f).get("district", ""))
        except:
            pass
    return {
        "total_conversions": len(records),
        "districts":         list(districts),
    }


# Keep old name for compatibility
load_training_stats = load_stats