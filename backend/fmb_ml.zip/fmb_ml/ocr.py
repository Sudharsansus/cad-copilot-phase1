"""
ocr.py — FMB Text Label Extractor
Uses Claude Vision API (primary) or Tesseract (fallback).

Text types in FMB drawings:
  corner_label      → A,B,C,D,E,F,G,H (red, at boundary corners)
  chain_point       → 11,12,13,14,16,18 (red, where chain meets boundary)
  boundary_dist     → 44,2  31,2  74,0 (black, on boundary lines)
  chain_dist        → (70,8)  (134,0)  (182,2) (black, on chain lines)
  subdivision_dist  → 41,0  38,6  73,2 (black, on subdivision lines)
  survey_number     → 400,403,405,416,417,612 (magenta, neighbor parcels)
  subdivision_label → 1, 2A, 2B, 3 (cyan, area labels)
  header            → district, taluk, village, scale
"""
import base64
import json
import re
import io


def extract_with_claude(img_bytes: bytes, api_key: str) -> list:
    """
    Send FMB image to Claude Vision API.
    Claude understands FMB context → better accuracy than Tesseract.
    
    Returns list of {text, x, y, color, type}
    """
    import anthropic

    client = anthropic.Anthropic(api_key=api_key)
    b64    = base64.standard_b64encode(img_bytes).decode()

    prompt = """You are analyzing a Tamil Nadu Government FMB (Field Measurement Book) survey drawing.

Extract ALL visible text from this image with exact positions.

For each text item return:
- text:  exact content as shown
- x:     horizontal position (0=left, 595=right)
- y:     vertical position (0=top, 841=bottom)
- color: "red", "blue", or "black"
- type:  classify as one of:
    "corner_label"      → Single letters A,B,C,D,E,F,G,H in RED at boundary corners
    "chain_point"       → Numbers 11,12,13,14,16,18 in RED on boundary line
    "boundary_dist"     → Measurements on boundary lines like 44,2  31,2  74,0  76,4
    "chain_dist"        → Distances in brackets like (70,8)  (134,0)  (182,2)  (74,6)
    "subdivision_dist"  → Internal line measurements like 41,0  38,6  73,2  49,4
    "survey_number"     → 3-4 digit parcel numbers like 400,403,405,416,417,612
    "subdivision_label" → Area labels like 1, 2A, 2B, 3
    "header"            → District/Taluk/Village/Scale/SurveyNo text

Important rules:
- Numbers like 44,2 or 44.2 on boundary = boundary_dist
- Numbers in brackets (70,8) = chain_dist  
- 3-4 digit numbers = survey_number
- Single letters A-H in red = corner_label
- Numbers 11-18 in red = chain_point

Return ONLY a valid JSON array. No explanation text."""

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=4096,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {
                        "type":       "base64",
                        "media_type": "image/png",
                        "data":       b64,
                    },
                },
                {"type": "text", "text": prompt}
            ],
        }]
    )

    raw   = response.content[0].text.strip()
    match = re.search(r'\[.*\]', raw, re.DOTALL)
    if not match:
        return []

    try:
        results = json.loads(match.group())
        return [
            {
                "text":  str(r.get("text", "")).strip(),
                "x":     float(r.get("x", 0)),
                "y":     float(r.get("y", 0)),
                "color": str(r.get("color", "black")).lower(),
                "type":  str(r.get("type", "header")),
            }
            for r in results
            if r.get("text")
        ]
    except Exception as e:
        print(f"   Claude OCR parse error: {e}")
        return []


def extract_with_tesseract(img_bytes: bytes) -> list:
    """
    Tesseract OCR fallback (no API needed).
    Less accurate for colored text but works offline.
    
    Returns list of {text, x, y, color, type}
    """
    try:
        import pytesseract
        from PIL import Image
        import numpy as np

        pytesseract.pytesseract.tesseract_cmd = \
            r'C:\Program Files\Tesseract-OCR\tesseract.exe'

        img     = Image.open(io.BytesIO(img_bytes))
        img_arr = np.array(img)
        results = []

        # Pass 1: Full image — black text
        data = pytesseract.image_to_data(
            img,
            output_type=pytesseract.Output.DICT,
            config='--psm 11 --oem 3'
        )
        for i in range(len(data['text'])):
            txt = data['text'][i].strip()
            if not txt or int(data['conf'][i]) < 25:
                continue
            x = (data['left'][i] + data['width'][i]  / 2) / 2
            y = (data['top'][i]  + data['height'][i] / 2) / 2
            if y > 115:
                results.append({
                    "text":  txt,
                    "x":     x,
                    "y":     y,
                    "color": "black",
                    "type":  _classify_text_type(txt),
                })

        # Pass 2: Red pixels only — corner labels A-H and chain points
        red_mask = (
            (img_arr[:, :, 0] > 150) &
            (img_arr[:, :, 1] < 100) &
            (img_arr[:, :, 2] < 100)
        )
        red_img = np.full_like(img_arr, 255)
        red_img[red_mask] = img_arr[red_mask]

        rd = pytesseract.image_to_data(
            Image.fromarray(red_img),
            output_type=pytesseract.Output.DICT,
            config='--psm 11 --oem 3 '
                   '-c tessedit_char_whitelist=ABCDEFGH0123456789 '
        )
        for i in range(len(rd['text'])):
            txt = rd['text'][i].strip()
            if not txt or int(rd['conf'][i]) < 20:
                continue
            x = (rd['left'][i] + rd['width'][i]  / 2) / 2
            y = (rd['top'][i]  + rd['height'][i] / 2) / 2
            if y > 115:
                results.append({
                    "text":  txt,
                    "x":     x,
                    "y":     y,
                    "color": "red",
                    "type":  _classify_text_type(txt),
                })

        return results

    except Exception as e:
        print(f"   Tesseract error: {e}")
        return []


def _classify_text_type(txt: str) -> str:
    """Rule-based classification for Tesseract results"""
    if re.match(r'^[A-H]$', txt):        return "corner_label"
    if re.match(r'^\d{1,2}$', txt):      return "chain_point"
    if re.match(r'^\([\d.,]+\)$', txt):  return "chain_dist"
    if re.match(r'^\d{3,4}$', txt):      return "survey_number"
    if re.match(r'^[123][AB]?$', txt):   return "subdivision_label"
    try:
        v = float(txt.replace(",", "."))
        if 1 < v < 500:                   return "boundary_dist"
    except:
        pass
    return "header"


def extract_with_gemini(img_bytes: bytes, api_key: str) -> list:
    """
    Gemini 2.0 Flash OCR — free alternative to Claude Vision.
    Same accuracy level, no billing needed.
    """
    import google.generativeai as genai
    import json, re, io
    from PIL import Image

    genai.configure(api_key=api_key)
    model = genai.GenerativeModel("gemini-2.0-flash")

    img = Image.open(io.BytesIO(img_bytes))

    prompt = """Analyze this Tamil Nadu FMB (Field Measurement Book) survey drawing.

Extract ALL visible text. For each item return:
- text: exact content
- x: x position (0-595, left to right)
- y: y position (0-841, top to bottom)
- color: "red", "blue", or "black"
- type: one of:
  "corner_label"      → A,B,C,D,E,F,G,H (red letters at boundary corners)
  "chain_point"       → numbers 11-18 in red on boundary
  "boundary_dist"     → measurements on boundary like 44,2  31,2  74,0
  "chain_dist"        → distances in brackets (70,8)  (134,0)  (182,2)
  "subdivision_dist"  → internal measurements 41,0  38,6  73,2
  "survey_number"     → 3-4 digit SF numbers 400,403,416,417,612
  "subdivision_label" → area labels 1, 2A, 2B, 3
  "header"            → district, taluk, village, scale text

Return ONLY valid JSON array, no other text."""

    response = model.generate_content([prompt, img])
    raw      = response.text.strip()
    match    = re.search(r'\[.*\]', raw, re.DOTALL)
    if not match:
        return []

    try:
        results = json.loads(match.group())
        return [
            {
                "text":  str(r.get("text","")).strip(),
                "x":     float(r.get("x", 0)),
                "y":     float(r.get("y", 0)),
                "color": str(r.get("color","black")).lower(),
                "type":  str(r.get("type","header")),
            }
            for r in results if r.get("text")
        ]
    except Exception as e:
        print(f"   Gemini OCR parse error: {e}")
        return []