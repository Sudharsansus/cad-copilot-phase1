"""
scale.py — FMB Scale Factor Calculator
Verified against FMB 405 (1:1079) and FMB 252 (1:1919)
Max error < 1% on all boundary segments

Scale detection uses 6x zoom on header area for best accuracy.
"""
import re
import io

# Universal constant — derived from ground truth
# A→B = 44.2m, PDF = 115.87px, scale = 1079
# 44.2 / 115.87 / 1079 = 0.0003540730
SCALE_CONSTANT = 0.0003540730


def get_scale_factor(scale_ratio: int) -> float:
    """
    Convert PDF scale ratio to meters-per-pixel factor.
    Accuracy: < 1% error (verified on FMB 405 + FMB 252)
    """
    return scale_ratio * SCALE_CONSTANT


def detect_scale_from_page(page) -> int:
    """
    Detect scale from FMB PDF header using Tesseract.
    Uses 6x zoom on header area (top 120pt) for best accuracy.
    Returns integer scale ratio (e.g. 1079, 1919)
    Falls back to geometry-based detection if OCR fails.
    """
    import fitz

    # Method 1: High-zoom OCR on header area only
    scale = _ocr_header(page)
    if scale:
        print(f"   Scale detected (OCR): 1:{scale}")
        return scale

    # Method 2: Geometry-based from longest boundary segment
    scale = _geometry_scale(page)
    if scale:
        print(f"   Scale detected (geometry): 1:{scale}")
        return scale

    print(f"   Scale fallback: 1:1000")
    return 1000


def _ocr_header(page) -> int:
    """
    OCR the header area (top 120pt) at 6x zoom.
    Header contains 'Scale : 1 : 1079' text.
    """
    try:
        import pytesseract
        from PIL import Image
        import fitz

        pytesseract.pytesseract.tesseract_cmd = \
            r'C:\Program Files\Tesseract-OCR\tesseract.exe'

        # Crop to header area and render at 6x zoom
        header_rect = fitz.Rect(0, 0, page.rect.width, 120)
        pix = page.get_pixmap(
            matrix=fitz.Matrix(6, 6),
            clip=header_rect
        )
        img  = Image.open(io.BytesIO(pix.tobytes("png")))
        text = pytesseract.image_to_string(img, config="--psm 6 --oem 3")

        m = re.search(r'1\s*[:/]\s*(\d{3,5})', text)
        if m:
            return int(m.group(1))

        # Try finding any 3-5 digit number that looks like a scale
        candidates = re.findall(r'\b(\d{3,4})\b', text)
        for c in candidates:
            v = int(c)
            if 500 <= v <= 9999 and v != 1000:
                return v

    except Exception as e:
        pass

    return None


def _geometry_scale(page) -> int:
    """
    Estimate scale from longest boundary segment.
    The longest w=3 black segment ≈ 76.4m for most FMBs.
    Uses the known constant: longest_m / longest_px / 0.000353
    """
    import math, fitz

    max_px = 0
    pw = page.rect.width
    ph = page.rect.height

    for d in page.get_drawings():
        w = d.get("width") or 0
        c = d.get("color")
        if abs(w - 3.0) > 0.5 or c != (0., 0., 0.):
            continue
        for item in d.get("items", []):
            if item[0] != "l":
                continue
            p1, p2 = item[1], item[2]
            lenpx = math.hypot(p2.x - p1.x, p2.y - p1.y)
            is_border = (
                min(p1.x, p2.x) < 20 or max(p1.x, p2.x) > pw - 20 or
                min(p1.y, p2.y) < 20 or max(p1.y, p2.y) > ph - 20
            )
            if not is_border and lenpx > max_px:
                max_px = lenpx

    if max_px > 0:
        # Assume longest segment ≈ 76.4m (common in TN FMBs)
        # scale = length_m / (px * 0.000353)
        estimated = round(76.4 / (max_px * 0.000353) / 50) * 50  # round to 50
        if 500 <= estimated <= 5000:
            return estimated

    return None